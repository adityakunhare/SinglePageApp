<template>
    <div class="h-screen bg-white">
        <div class="flex">
            <div class="pl-6 bg-gray-200 w-48 border-r-2 border-gray-400 h-screen">
               <nav class="pt-4">
                    <router-link to="/">
                         <svg class="fill-current text-blue-600 pt-2 w-16" viewBox="0 0 94.666664 57.333332">
                            <path
                            d="M 27.999999,55.632984 C 27.999999,54.329795 24.729937,54.053684 14,54.450876 1.3821009,54.917955 0,54.739836 0,52.646623 0,50.546297 1.3711154,50.380565 14.333333,50.914095 L 28.666666,51.50406 33.079502,33.220082 C 37.955046,13.01893 37.65836,13.387785 49.060605,13.35154 c 4.389323,-0.01395 6.528516,0.783037 9.157104,3.411625 3.041193,3.041193 3.361928,4.248663 2.830563,10.656232 l -0.59927,7.226401 6.950501,-10.989565 C 79.519547,4.4930084 81.020894,2.6666666 84.653992,2.6666666 c 1.840303,0 3.346006,0.4672915 3.346006,1.0384254 0,0.5711342 1.190615,9.421134 2.645811,19.666666 3.336415,23.49053 3.344371,24.628241 0.172247,24.628241 -1.958881,0 -2.714306,-1.327237 -3.41503,-6 l -0.899756,-6 H 76.223786 65.944302 l -3.277637,6 c -2.413391,4.41792 -4.085049,6 -6.339725,6 -3.017854,0 -3.030251,-0.0626 -0.858207,-4.333333 l 2.203883,-4.333334 -3.169643,2.911184 c -4.047377,3.717347 -9.449998,5.755483 -15.256441,5.755483 -2.774384,0 -4.580325,0.657036 -4.581029,1.666667 -9.04e-4,1.295297 6.683745,1.581545 29.999999,1.284651 26.684125,-0.339778 30.001162,-0.147801 30.001162,1.736346 0,1.885876 -3.365757,2.074132 -30.66798,1.715349 -23.860961,-0.313561 -30.667689,-0.03308 -30.666666,1.263653 7.22e-4,0.916667 -1.198686,1.666667 -2.665352,1.666667 -1.466667,0 -2.666667,-0.765157 -2.666667,-1.700348 z m 18.553592,-13.96839 c 2.504474,-1.282194 5.654474,-4.4219 6.999999,-6.977125 5.112786,-9.709463 1.726056,-17.967027 -7.019318,-17.114583 -4.334632,0.422512 -4.414617,0.556379 -7.425168,12.427113 -1.673834,6.6 -3.058133,12.45 -3.07622,13 -0.05915,1.798627 5.868809,1.046184 10.520707,-1.335405 z M 85.503306,31.385581 C 86.37809,30.510795 83.789183,9.3333331 82.807459,9.3333331 c -0.911001,0 -13.474128,20.2594519 -13.474128,21.7285409 0,1.022105 15.167929,1.325751 16.169975,0.323707 z M 2.8057102,46.780815 c -1.0643768,-0.673959 -1.4952366,-2.1314 -1.0065677,-3.404851 0.641761,-1.672402 1.6026186,-1.954757 3.8609563,-1.134566 9.1397952,3.31942 19.6732342,-0.438947 19.6732342,-7.019477 0,-3.629915 -2.271736,-6.079956 -9.300224,-10.030188 C 6.8838537,20.049564 6.2055201,10.021686 14.622148,4.3333332 20.866793,0.11290788 35.999999,0.40325147 35.999999,4.7434858 c 0,2.7585672 -1.907565,3.2880728 -6.795366,1.8862702 -6.199483,-1.7779884 -12.943897,0.5338118 -14.015695,4.804196 -1.183261,4.714489 0.01646,6.70725 6.414033,10.653831 7.439683,4.589446 9.063695,6.785216 9.063695,12.254711 0,5.8977 -1.870135,9.177122 -6.639979,11.643705 -4.231765,2.188331 -18.1942106,2.711152 -21.2209768,0.794616 z"
                            id="path14" inkscape:connector-curvature="0" />
                        </svg>
                    </router-link>

                    <p class=" pt-12 text-gray-500 font-bold text-xs uppercase">Create</p>
                    <router-link to="/contacts/create" class="flex pt-3 items-center" >
                        <svg  viewBox="0 0 24 24" class="fill-current text-blue-600 w-4 h-4"><path d="M23.3 11.9c0 .9-.6 1.4-1.4 1.4h-8.5v8.5c0 .9-.6 1.4-1.4 1.4s-1.4-.6-1.4-1.4v-8.5H2c-.9 0-1.4-.6-1.4-1.4 0-.9.6-1.4 1.4-1.4h8.5V1.9c0-.9.6-1.4 1.4-1.4s1.4.6 1.4 1.4v8.5h8.5c.9 0 1.5.6 1.5 1.5z"/></svg>
                        <div class="text-blue-600 hover:text-blue-400 text-xs font-bold pl-3 tracking-wide">Add New</div>
                    </router-link>

                    <p class=" pt-12 text-gray-500 font-bold text-xs uppercase">General</p>
                    <router-link to="/contacts" class="flex pt-3 items-center" >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="fill-current text-blue-600 w-5 h-5"><path class="st0" d="M20 2h-1V1c0-.6-.4-1-1-1s-1 .4-1 1v1h-4V1c0-.6-.4-1-1-1s-1 .4-1 1v1H7V1c0-.6-.4-1-1-1S5 .4 5 1v1H4C1.8 2 0 3.8 0 6v14c0 2.2 1.8 4 4 4h16c2.2 0 4-1.8 4-4V6c0-2.2-1.8-4-4-4zM4 4h1v1c0 .6.4 1 1 1s1-.4 1-1V4h4v1c0 .6.4 1 1 1s1-.4 1-1V4h4v1c0 .6.4 1 1 1s1-.4 1-1V4h1c1.1 0 2 .9 2 2v2H2V6c0-1.1.9-2 2-2zm16 18H4c-1.1 0-2-.9-2-2V10h20v10c0 1.1-.9 2-2 2zM8 14c0 .6-.4 1-1 1H5c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1zm6 0c0 .6-.4 1-1 1h-2c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1zm6 0c0 .6-.4 1-1 1h-2c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1zM8 18c0 .6-.4 1-1 1H5c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1zm6 0c0 .6-.4 1-1 1h-2c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1zm6 0c0 .6-.4 1-1 1h-2c-.6 0-1-.4-1-1s.4-1 1-1h2c.6 0 1 .4 1 1z"/></svg>
                        <div class="text-blue-600 hover:text-blue-400 text-xs font-bold pl-3 tracking-wide">Contacts</div>
                    </router-link>
                    <router-link to="/birthdays" class="flex pt-3 items-center" >
                        <svg viewBox="0 0 24 24" class="fill-current text-blue-600 w-5 h-5"><path fill-rule="evenodd" d="M12.1 6.8c1.2 0 2.1-1 2.1-2.1 0-.4-.1-.8-.3-1.1L12.1.5l-1.8 3.1c-.2.3-.3.6-.3 1 0 1.2 1 2.2 2.1 2.2zm6.4 3.1h-5.3V7.8h-2.1v2.1H5.8c-1.8 0-3.2 1.4-3.2 3.2v9.5c0 .6.5 1.1 1.1 1.1h16.9c.6 0 1.1-.5 1.1-1.1v-9.5c0-1.8-1.5-3.2-3.2-3.2zm1 11.7H4.7v-3.2c1 0 1.9-.4 2.5-1.1l1.2-1.1 1.1 1.1c1.4 1.4 3.8 1.4 5.2 0l1.1-1.1 1.1 1.1c.7.7 1.6 1.1 2.5 1.1v3.2h.1zm0-4.8c-.5 0-1-.2-1.4-.6l-2.3-2.3-2.3 2.3c-.8.8-2.1.8-2.9 0l-2.3-2.3L6 16.2c-.4.4-.9.6-1.4.6v-3.7c0-.6.5-1.1 1.1-1.1h12.7c.6 0 1.1.5 1.1 1.1v3.7z" clip-rule="evenodd"/></svg>
                        <div class="text-blue-600 hover:text-blue-400 text-xs font-bold pl-3 tracking-wide">Birthdays</div>
                    </router-link>

                    <p class=" pt-12 text-gray-500 font-bold text-xs uppercase">Settings</p>
                    <router-link to="/logout" class="flex pt-3 items-center" >
                        <svg viewBox="0 0 24 24" class="fill-current text-blue-600 w-5 h-5"><path d="M21 3h-3.8c-.7 0-1.3-.6-1.3-1.3S16.5.4 17.2.4h5.1c.7 0 1.3.6 1.3 1.3v20.5c0 .7-.6 1.3-1.3 1.3h-5.1c-.7 0-1.3-.6-1.3-1.3 0-.7.6-1.3 1.3-1.3H21V3zm-6.9 7.7L8.6 5.2c-.5-.5-.6-1.3-.1-1.8s1.3-.5 1.8 0l7.7 7.7c.8.8.2 2.2-.9 2.2H1.8c-.7 0-1.3-.6-1.3-1.3 0-.7.6-1.3 1.3-1.3h12.3zm-1.6 4.8c.5-.5 1.3-.4 1.8.1s.4 1.3-.1 1.8l-3.8 3.2c-.5.5-1.3.4-1.8-.1-.6-.5-.5-1.3 0-1.7l3.9-3.3z"/></svg>
                        <div class="text-blue-600 hover:text-blue-400 text-xs font-bold pl-3 tracking-wide">Logout</div>
                    </router-link>
               </nav>
            </div>
            <div class="flex flex-col h-screen overflow-y-hidden flex-1">
                <div class="h-16 px-6 border-b border-gray-400 flex items-center justify-between w-auto">
                    <div class="">
                        {{ title }}
                    </div>
                    <div class="flex items-center">
                        <SearchBar/>
                        <UserCircle :name="user.name" />
                    </div>
                </div>
                <div class=" flex flex-col overflow-y-hidden flex-1">
                    <router-view class=" p-6 overflow-x-hidden " :key="$route.fullPath">
                    </router-view>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import UserCircle from '../components/UserCircle'
import SearchBar from '../components/SearchBar'

export default {
    name: "App",
    props:[
        'user',

    ],
    components:{
        UserCircle, SearchBar
    },
    data: function(){
        return{
            title:'',
        }
    },
    watch:{
        $route(to, from){
            this.title = to.meta.title;
        },
        title(){
            document.title = this.title + '  | SpA' ; 
        }
    },
    created(){
        this.title = this.$route.meta.title;
        window.axios.interceptors.request.use(
            (config) => {
                if(config.method === 'get'){
                    config.url = config.url + '?api_token=' + this.user.api_token;
                }else{
                    config.data ={
                        ...config.data, 
                        api_token: this.user.api_token
                    };
                }
                return config;
            }
        )
    }
}
</script>

<style>

</style>