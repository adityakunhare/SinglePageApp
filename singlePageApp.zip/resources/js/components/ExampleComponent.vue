<template>
    <div>
        Welcome to Single Page Applicatioon
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
